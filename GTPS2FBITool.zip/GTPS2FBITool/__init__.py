bl_info = {
    "name": "GTPS2FBITool",
    "author": "Saif/Claude",
    "version": (1, 0, 0),
    "blender": (4, 5, 0),
    "location": "View3D > Sidebar > GTPS2FBITool",
    "description": "Import/export Gran Turismo 3 .FBI scene files: "
                   "camera, lights, and car animations parameters",
    "category": "Import-Export",
}

import base64
import math
import os
import struct

import bpy
from bpy.props import (
    CollectionProperty, FloatProperty, FloatVectorProperty, PointerProperty,
    StringProperty,
)
from bpy_extras.io_utils import ExportHelper, ImportHelper
from mathutils import Vector

from . import fbi_format as fmt

COLLECTION_NAME = "GT3 FBI"
CAMERA_NAME = "FBI_Camera"
LIGHT_PREFIX = "FBI_Light_"


def gt3_to_blender(v):
    return Vector((v[0], -v[2], v[1]))


def blender_to_gt3(v):
    return (v.x, v.z, -v.y)


def _wget(word):
    def get(self):
        i = word - 4
        return self.words[i].value if i < len(self.words) else 0.0
    return get


def _wset(word):
    def set_(self, value):
        i = word - 4
        if i < len(self.words):
            self.words[i].value = value
    return set_


def _cget(word):
    def get(self):
        i = word - 4
        if i + 2 < len(self.words):
            return (self.words[i].value,
                    self.words[i + 1].value,
                    self.words[i + 2].value)
        return (0.0, 0.0, 0.0)
    return get


def _cset(word):
    def set_(self, value):
        i = word - 4
        if i + 2 < len(self.words):
            for k in range(3):
                self.words[i + k].value = value[k]
    return set_


def _tail_prop(key, **kwargs):
    word, label, conf, desc = fmt.TAIL_MAP[key]
    return FloatProperty(
        name=label,
        description=desc,
        get=_wget(word), set=_wset(word),
        precision=3, **kwargs)


class FBIWord(bpy.types.PropertyGroup):
    value: FloatProperty(name="Value", default=0.0, precision=4)


class FBISettings(bpy.types.PropertyGroup):
    filepath: StringProperty(name="Source File")
    raw_b64: StringProperty()

    words: CollectionProperty(type=FBIWord)

    ambient: FloatVectorProperty(
        name="Ambient Tint", subtype='COLOR', size=3, min=0.0, soft_max=2.0,
        description="Ambient/material tint RGB",
        get=_cget(fmt.AMBIENT_BASE), set=_cset(fmt.AMBIENT_BASE))
    light_top: FloatVectorProperty(
        name="Top Light", subtype='COLOR', size=3, min=0.0, soft_max=2.0,
        description="Top light diffuse RGB",
        get=_cget(12), set=_cset(12))
    light_posx: FloatVectorProperty(
        name="Right Light (+X)", subtype='COLOR', size=3, min=0.0, soft_max=2.0,
        description="Right side light diffuse RGB",
        get=_cget(28), set=_cset(28))
    light_negx: FloatVectorProperty(
        name="Left Light (-X)", subtype='COLOR', size=3, min=0.0, soft_max=2.0,
        description="Left side light diffuse RGB",
        get=_cget(44), set=_cset(44))

    cam_yaw: _tail_prop("cam_yaw", soft_min=-360.0, soft_max=360.0)
    cam_pitch: _tail_prop("cam_pitch", soft_min=-90.0, soft_max=90.0)
    cam_vert: _tail_prop("cam_vert", soft_min=-180.0, soft_max=180.0)
    cam_fov: _tail_prop("cam_fov", soft_min=1.0, soft_max=120.0)
    cam_zdist: _tail_prop("cam_zdist", soft_min=0.1, soft_max=100.0)
    spin_speed: _tail_prop("spin_speed", soft_min=0.0, soft_max=60.0)
    spin_center: _tail_prop("spin_center", soft_min=-50.0, soft_max=50.0)
    spin_center2: _tail_prop("spin_center2", soft_min=-50.0, soft_max=50.0)
    anim_spawn: _tail_prop("spawn", soft_min=-200.0, soft_max=200.0)
    anim_slide: _tail_prop("slide", soft_min=0.0, soft_max=100.0)
    anim_easing: _tail_prop("easing", soft_min=0.0, soft_max=1.0)
    anim_wobble: _tail_prop("wobble", soft_min=0.0, soft_max=30.0)
    anim_popin: _tail_prop("popin", soft_min=0.0, soft_max=20.0)
    car_x: _tail_prop("car_x", soft_min=-50.0, soft_max=50.0)
    car_y: _tail_prop("car_y", soft_min=-50.0, soft_max=50.0)
    car_z: _tail_prop("car_z", soft_min=-50.0, soft_max=50.0)
    car_y2: _tail_prop("car_y2", soft_min=-50.0, soft_max=50.0)


def _get_collection(context):
    coll = bpy.data.collections.get(COLLECTION_NAME)
    if coll is None:
        coll = bpy.data.collections.new(COLLECTION_NAME)
    if COLLECTION_NAME not in context.scene.collection.children:
        context.scene.collection.children.link(coll)
    return coll


def _get_or_create(context, name, data_factory):
    obj = bpy.data.objects.get(name)
    if obj is None:
        obj = bpy.data.objects.new(name, data_factory())
        _get_collection(context).objects.link(obj)
    return obj


def build_lights(context, st):
    for base, suffix in fmt.LIGHT_RECORDS:
        name = LIGHT_PREFIX + suffix
        obj = _get_or_create(
            context, name,
            lambda n=name: bpy.data.lights.new(n, type='SUN'))
        rgb = [st.words[base - 4 + k].value for k in range(3)]
        obj.data.color = rgb
        obj.data.energy = 3.0

        d = base - 4 + fmt.LIGHT_DIR
        toward = gt3_to_blender(
            (st.words[d].value, st.words[d + 1].value, st.words[d + 2].value))
        if toward.length < 1e-6:
            toward = Vector((0.0, 0.0, 1.0))
        toward.normalize()
        obj.location = toward * 10.0
        travel = -toward
        obj.rotation_euler = travel.to_track_quat('-Z', 'Y').to_euler()

    if context.scene.world:
        context.scene.world.color = st.ambient


def build_camera(context, st):
    obj = _get_or_create(
        context, CAMERA_NAME,
        lambda: bpy.data.cameras.new(CAMERA_NAME))
    az = math.radians(st.cam_yaw)
    el = math.radians(-st.cam_pitch)
    d = max(st.cam_zdist, 0.1)
    pos = Vector((d * math.cos(el) * math.sin(az),
                  -d * math.cos(el) * math.cos(az),
                  d * math.sin(el)))
    obj.location = pos
    look = (-pos).normalized()
    obj.rotation_euler = look.to_track_quat('-Z', 'Y').to_euler()

    cam = obj.data
    cam.sensor_fit = 'VERTICAL'
    cam.lens_unit = 'FOV'
    cam.angle = math.radians(max(st.cam_fov, 1.0))
    if context.scene.camera is None:
        context.scene.camera = obj
    return obj


def camera_to_words(st, cam_obj):
    p = cam_obj.matrix_world.translation
    d = p.length
    if d < 1e-6:
        return
    el = math.asin(max(-1.0, min(1.0, p.z / d)))
    st.cam_pitch = -math.degrees(el)
    st.cam_yaw = math.degrees(math.atan2(p.x, -p.y))
    st.cam_zdist = d
    st.cam_fov = math.degrees(cam_obj.data.angle)


def lights_to_words(st):
    for base, suffix in fmt.LIGHT_RECORDS:
        obj = bpy.data.objects.get(LIGHT_PREFIX + suffix)
        if obj is None or obj.type != 'LIGHT':
            continue
        for k in range(3):
            st.words[base - 4 + k].value = obj.data.color[k]
        travel = obj.matrix_world.to_quaternion() @ Vector((0.0, 0.0, -1.0))
        gx, gy, gz = blender_to_gt3(-travel)
        d = base - 4 + fmt.LIGHT_DIR
        st.words[d].value = gx
        st.words[d + 1].value = gy
        st.words[d + 2].value = gz


class FBI_OT_import(bpy.types.Operator, ImportHelper):
    """Import a GT3 .fbi showroom file and build the scene"""
    bl_idname = "gt3fbi.import_file"
    bl_label = "Import .fbi"
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext = ".fbi"
    filter_glob: StringProperty(default="*.fbi", options={'HIDDEN'})

    def execute(self, context):
        try:
            with open(self.filepath, "rb") as fh:
                data = fh.read()
            raw_header, header_ints, floats = fmt.parse_fbi(data)
        except (OSError, ValueError) as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}

        st = context.scene.gt3_fbi
        st.filepath = self.filepath
        st.raw_b64 = base64.b64encode(data).decode("ascii")
        st.words.clear()
        for v in floats:
            st.words.add().value = v

        build_lights(context, st)
        build_camera(context, st)

        if header_ints[0] != len(floats):
            self.report({'WARNING'},
                        f"Header count={header_ints[0]} but file holds "
                        f"{len(floats)} floats — imported anyway")
        else:
            self.report({'INFO'},
                        f"Imported {os.path.basename(self.filepath)} "
                        f"({len(floats)} values)")
        return {'FINISHED'}


class FBI_OT_export(bpy.types.Operator, ExportHelper):
    """Bake the current values back into a structurally identical .fbi file"""
    bl_idname = "gt3fbi.export_file"
    bl_label = "Export .fbi"

    filename_ext = ".fbi"
    filter_glob: StringProperty(default="*.fbi", options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        return len(context.scene.gt3_fbi.words) > 0

    def invoke(self, context, event):
        st = context.scene.gt3_fbi
        if st.filepath and not self.filepath:
            self.filepath = st.filepath
        return super().invoke(context, event)

    def execute(self, context):
        st = context.scene.gt3_fbi
        raw = base64.b64decode(st.raw_b64)
        raw_header = raw[:fmt.HEADER_BYTES]

        lights_to_words(st)
        cam = bpy.data.objects.get(CAMERA_NAME)
        if cam is not None:
            camera_to_words(st, cam)

        floats = [w.value for w in st.words]
        out = fmt.serialize_fbi(raw_header, floats)

        if len(out) != len(raw):
            self.report({'ERROR'},
                        f"Refusing to write: size {len(out)} != original "
                        f"{len(raw)} (structure must stay identical)")
            return {'CANCELLED'}

        try:
            with open(self.filepath, "wb") as fh:
                fh.write(out)
        except OSError as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}

        self.report({'INFO'},
                    f"Wrote {os.path.basename(self.filepath)} "
                    f"({len(out)} bytes, header preserved verbatim)")
        return {'FINISHED'}


class FBI_OT_rebuild(bpy.types.Operator):
    """Rebuild the FBI camera and lights from the current slider values"""
    bl_idname = "gt3fbi.rebuild"
    bl_label = "Values → Scene Objects"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return len(context.scene.gt3_fbi.words) > 0

    def execute(self, context):
        st = context.scene.gt3_fbi
        build_lights(context, st)
        build_camera(context, st)
        return {'FINISHED'}


class FBI_OT_camera_from_view(bpy.types.Operator):
    """Snap the FBI camera and its values to the current viewport angle"""
    bl_idname = "gt3fbi.camera_from_view"
    bl_label = "Use Current Viewport Angle"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (len(context.scene.gt3_fbi.words) > 0
                and context.region_data is not None)

    def execute(self, context):
        st = context.scene.gt3_fbi
        cam = _get_or_create(
            context, CAMERA_NAME, lambda: bpy.data.cameras.new(CAMERA_NAME))
        cam.matrix_world = context.region_data.view_matrix.inverted()
        camera_to_words(st, cam)
        build_camera(context, st)
        return {'FINISHED'}


def _set_interp(obj, data_path, interpolation, easing, index=None):
    anim = obj.animation_data
    if anim is None or anim.action is None:
        return
    for fc in anim.action.fcurves:
        if fc.data_path == data_path and (index is None or fc.array_index == index):
            for kp in fc.keyframe_points:
                kp.interpolation = interpolation
                kp.easing = easing


class FBI_OT_preview(bpy.types.Operator):
    """Preview the entrance and turntable spin on the selected car object"""
    bl_idname = "gt3fbi.preview_entrance"
    bl_label = "Preview Entrance + Spin"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return len(context.scene.gt3_fbi.words) > 0

    def execute(self, context):
        st = context.scene.gt3_fbi
        scene = context.scene
        fps = scene.render.fps

        obj = context.active_object
        if (obj is None or obj.type not in {'MESH', 'EMPTY'}
                or obj.name.startswith(LIGHT_PREFIX)
                or obj.name == CAMERA_NAME):
            self.report({'ERROR'},
                        "Select your car model in the viewport, then click "
                        "Preview")
            return {'CANCELLED'}

        obj.animation_data_clear()
        obj.rotation_mode = 'XYZ'

        rest = obj.location.copy()
        spawn = st.anim_spawn
        slide = max(abs(st.anim_slide), 0.01)
        slide_frames = max(int(abs(spawn) / slide * fps), 2) if spawn else 2
        f0, f1 = 1, 1 + slide_frames

        obj.location = (rest.x + spawn, rest.y, rest.z)
        obj.keyframe_insert("location", frame=f0)
        obj.location = rest
        obj.keyframe_insert("location", frame=f1)
        if st.anim_easing <= 0.01:
            _set_interp(obj, "location", 'LINEAR', 'AUTO')
        elif st.anim_easing < 0.45:
            _set_interp(obj, "location", 'QUAD', 'EASE_OUT')
        else:
            _set_interp(obj, "location", 'CUBIC', 'EASE_OUT')

        pop_frames = max(int(fps / max(st.anim_popin, 0.01)), 2)
        obj.scale = (0.01, 0.01, 0.01)
        obj.keyframe_insert("scale", frame=f0)
        obj.scale = (1.0, 1.0, 1.0)
        obj.keyframe_insert("scale", frame=f0 + pop_frames)
        _set_interp(obj, "scale", 'BACK', 'EASE_OUT')

        amp = math.radians(st.anim_wobble)
        per = max(int(fps * 0.15), 2)
        obj.rotation_euler[0] = 0.0
        obj.keyframe_insert("rotation_euler", index=0, frame=f1)
        for i in range(1, 5):
            obj.rotation_euler[0] = amp * (0.5 ** i) * (1 if i % 2 else -1)
            obj.keyframe_insert("rotation_euler", index=0, frame=f1 + i * per)
        obj.rotation_euler[0] = 0.0
        obj.keyframe_insert("rotation_euler", index=0, frame=f1 + 5 * per)
        wobble_end = f1 + 5 * per

        spin_seconds = 8.0
        spin_end = wobble_end + int(spin_seconds * fps)
        deg_per_sec = st.spin_speed * 12.0
        obj.rotation_euler[2] = 0.0
        obj.keyframe_insert("rotation_euler", index=2, frame=wobble_end)
        obj.rotation_euler[2] = math.radians(deg_per_sec * spin_seconds)
        obj.keyframe_insert("rotation_euler", index=2, frame=spin_end)
        _set_interp(obj, "rotation_euler", 'LINEAR', 'AUTO', index=2)

        scene.frame_start = 1
        scene.frame_end = spin_end
        scene.frame_current = 1
        bpy.ops.screen.animation_cancel(restore_frame=False)
        bpy.ops.screen.animation_play()
        return {'FINISHED'}


class FBI_PT_main(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "GT3 FBI"
    bl_label = "GT3 .FBI Showroom Tool"

    def draw(self, context):
        st = context.scene.gt3_fbi
        col = self.layout.column()
        row = col.row(align=True)
        row.operator(FBI_OT_import.bl_idname, icon='IMPORT')
        row.operator(FBI_OT_export.bl_idname, icon='EXPORT')
        if not st.words:
            col.separator()
            col.label(text="Import a .fbi file to begin", icon='INFO')
            return
        col.label(text=os.path.basename(st.filepath) or "(unsaved)",
                  icon='FILE')
        col.label(text=f"{len(st.words)} values loaded — header preserved",
                  icon='LOCKED')


class FBI_PT_camera(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "GT3 FBI"
    bl_parent_id = "FBI_PT_main"
    bl_label = "Camera"

    @classmethod
    def poll(cls, context):
        return len(context.scene.gt3_fbi.words) > 0

    def draw(self, context):
        st = context.scene.gt3_fbi
        col = self.layout.column(align=True)
        col.prop(st, "cam_yaw")
        col.prop(st, "cam_pitch")
        col.prop(st, "cam_vert")
        col.prop(st, "cam_fov")
        col.prop(st, "cam_zdist")
        col = self.layout.column()
        col.operator(FBI_OT_camera_from_view.bl_idname, icon='VIEW_CAMERA')
        col.operator(FBI_OT_rebuild.bl_idname, icon='FILE_REFRESH')


class FBI_PT_lighting(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "GT3 FBI"
    bl_parent_id = "FBI_PT_main"
    bl_label = "Lighting"

    @classmethod
    def poll(cls, context):
        return len(context.scene.gt3_fbi.words) > 0

    def draw(self, context):
        st = context.scene.gt3_fbi
        col = self.layout.column()
        col.prop(st, "ambient")
        col.prop(st, "light_top")
        col.prop(st, "light_posx")
        col.prop(st, "light_negx")
        col.label(text="Rotate FBI_Light_* objects to re-aim",
                  icon='ORIENTATION_GIMBAL')


class FBI_PT_animation(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "GT3 FBI"
    bl_parent_id = "FBI_PT_main"
    bl_label = "Car Entrance Animation"

    @classmethod
    def poll(cls, context):
        return len(context.scene.gt3_fbi.words) > 0

    def draw(self, context):
        st = context.scene.gt3_fbi
        col = self.layout.column(align=True)
        col.prop(st, "anim_spawn")
        col.prop(st, "anim_slide")
        col.prop(st, "anim_easing")
        col.prop(st, "anim_wobble")
        col.prop(st, "anim_popin")
        self.layout.operator(FBI_OT_preview.bl_idname, icon='PLAY')


class FBI_PT_spin(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "GT3 FBI"
    bl_parent_id = "FBI_PT_main"
    bl_label = "Car Spin & Placement"

    @classmethod
    def poll(cls, context):
        return len(context.scene.gt3_fbi.words) > 0

    def draw(self, context):
        st = context.scene.gt3_fbi
        col = self.layout.column(align=True)
        col.label(text="Turntable Spin", icon='FILE_REFRESH')
        col.prop(st, "spin_speed")
        col.prop(st, "spin_center")
        col.prop(st, "spin_center2")
        col = self.layout.column(align=True)
        col.label(text="Car Placement", icon='OBJECT_ORIGIN')
        col.prop(st, "car_x")
        col.prop(st, "car_y")
        col.prop(st, "car_z")
        col.prop(st, "car_y2")


class FBI_PT_advanced(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "GT3 FBI"
    bl_parent_id = "FBI_PT_main"
    bl_label = "Advanced: Raw Tail Values"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return len(context.scene.gt3_fbi.words) > 0

    def draw(self, context):
        st = context.scene.gt3_fbi
        labels = {w: label for _, (w, label, _, _) in fmt.TAIL_MAP.items()}
        col = self.layout.column(align=True)
        for w in range(fmt.TAIL_START, fmt.TAIL_END):
            i = w - 4
            if i >= len(st.words):
                break
            col.prop(st.words[i], "value", text=labels.get(w, f"w{w}"))


classes = (
    FBIWord,
    FBISettings,
    FBI_OT_import,
    FBI_OT_export,
    FBI_OT_rebuild,
    FBI_OT_camera_from_view,
    FBI_OT_preview,
    FBI_PT_main,
    FBI_PT_camera,
    FBI_PT_lighting,
    FBI_PT_animation,
    FBI_PT_spin,
    FBI_PT_advanced,
)


def menu_import(self, context):
    self.layout.operator(FBI_OT_import.bl_idname,
                         text="GT3 Showroom Scene (.fbi)")


def menu_export(self, context):
    self.layout.operator(FBI_OT_export.bl_idname,
                         text="GT3 Showroom Scene (.fbi)")


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.gt3_fbi = PointerProperty(type=FBISettings)
    bpy.types.TOPBAR_MT_file_import.append(menu_import)
    bpy.types.TOPBAR_MT_file_export.append(menu_export)


def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(menu_import)
    bpy.types.TOPBAR_MT_file_export.remove(menu_export)
    del bpy.types.Scene.gt3_fbi
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
