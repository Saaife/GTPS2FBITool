import struct

HEADER_BYTES = 16
WORD = 4

AMBIENT_BASE = 4
LIGHT_RECORDS = [
    (12, "Top"),
    (28, "PosX"),
    (44, "NegX"),
]
LIGHT_DIFFUSE = 0
LIGHT_SPECULAR = 4
LIGHT_DIR = 8
LIGHT_PAD = 12

TAIL_START = 60
TAIL_END = 80

TAIL_MAP = {
    "spin_speed":   (71, "Car Spin Speed",      "confirmed", "Turntable rotation speed of the car"),
    "spin_center":  (60, "Spin Center",         "confirmed", "Car spin centering value"),
    "spin_center2": (62, "Spin Center 2",       "confirmed", "Car spin centering value, second axis"),
    "cam_yaw":   (66, "Camera Yaw",           "confirmed", "Camera yaw in degrees"),
    "cam_pitch": (65, "Camera Pitch",         "confirmed", "Camera pitch in degrees"),
    "cam_zdist": (64, "Camera Distance",      "confirmed", "Camera distance from the car"),
    "cam_fov":   (79, "Camera FOV",           "confirmed", "Field of view in degrees"),
    "cam_vert":  (69, "Camera Vertical Aim",  "confirmed", "Camera up/down framing during animation"),
    "spawn":  (70, "Spawn Distance",     "med",       "How far the car spawns before sliding in"),
    "slide":  (73, "Slide Speed",        "confirmed", "How fast the car slides into frame"),
    "wobble": (74, "Wobble Aggression",  "confirmed", "How much the car rocks as it enters"),
    "easing": (61, "Easing",             "high",      "Slow-down curve of the entrance"),
    "popin":  (67, "Pop-in Scale Speed", "high",      "How fast the car scales/fades in"),
    "car_x":  (76, "Car X",       "confirmed", "Car location X"),
    "car_y":  (75, "Car Y",       "confirmed", "Car location Y"),
    "car_z":  (77, "Car Z",       "confirmed", "Car location Z"),
    "car_y2": (78, "Car Y (alt)", "med",       "Secondary car Y offset"),
    "unused68": (68, "(no effect)", "confirmed", "No observed effect"),
}


def parse_fbi(data):
    if len(data) < HEADER_BYTES or len(data) % WORD != 0:
        raise ValueError(
            f"not a valid .fbi: size {len(data)} is not header + whole words")
    raw_header = data[:HEADER_BYTES]
    header_ints = struct.unpack("<4I", raw_header)
    body = data[HEADER_BYTES:]
    floats = list(struct.unpack(f"<{len(body) // WORD}f", body))
    return raw_header, header_ints, floats


def serialize_fbi(raw_header, floats):
    if len(raw_header) != HEADER_BYTES:
        raise ValueError("header must be exactly 16 bytes")
    return bytes(raw_header) + struct.pack(f"<{len(floats)}f", *floats)


if __name__ == "__main__":
    import sys
    path = sys.argv[1] if len(sys.argv) > 1 else "showroom_dealer.fbi"
    original = open(path, "rb").read()
    hdr, ints, floats = parse_fbi(original)
    rebuilt = serialize_fbi(hdr, floats)
    assert rebuilt == original, "round trip FAILED"
    print(f"OK: {path} round-trips byte-perfect "
          f"({len(original)} bytes, count={ints[0]}, flags={ints[1]}, "
          f"{len(floats)} floats)")
